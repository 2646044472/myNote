from diffusers import StableDiffusionPipeline
import torch

model_path = "sd-lora"
pipe = StableDiffusionPipeline.from_pretrained(
    "CompVis/stable-diffusion-v1-4",
    torch_dtype=torch.float16,
    safety_checker=None,
    requires_safety_checker=False
)

pipe.unet.load_attn_procs(model_path)
pipe.to("cuda")

prompt = "sketch of luxury house"
image = pipe(prompt, num_inference_steps=50, guidance_scale=8).images[0]
image.save("lora.png")
